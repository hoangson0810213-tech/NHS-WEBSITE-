HOANGSON VIP HUB — BẢN CÓ TRANG ADMIN QUẢN LÝ DOWNLOAD

XEM THỬ TRÊN ACODE
1. Giải nén ZIP.
2. Mở thư mục hoangson_vip_hub trong Acode.
3. Mở index.html và chọn Preview để xem trang chủ.
4. Mở download.html để xem giao diện kho tải.
Lưu ý: Acode Preview chỉ xem giao diện. Admin/API cần deploy Cloudflare Pages và cấu hình D1 mới lưu link cho mọi khách truy cập.

ĐƯA LÊN CLOUDFLARE PAGES (CÓ LƯU LINK THẬT)
1. Vào https://dash.cloudflare.com/ và đăng nhập.
2. Mở Workers & Pages → Create → Pages → Direct Upload.
3. Upload toàn bộ nội dung thư mục này, gồm index.html, download.html, admin.html, thư mục functions và schema.sql.
4. Tạo project Pages và deploy.
5. Tạo D1 database tên ví dụ hoangson-downloads.
6. Mở database → Console, dán nội dung schema.sql rồi chạy.
7. Vào project Pages → Settings → Functions → D1 database bindings.
   Variable name: DB
   Chọn database hoangson-downloads.
8. Vào project Pages → Settings → Variables and Secrets.
   Thêm secret ADMIN_PASSWORD với mật khẩu mạnh do bạn tự đặt.
9. Deploy lại project nếu cần.
10. Mở https://TEN-DU-AN.pages.dev/admin.html để đăng nhập và quản lý link.
11. Khách xem danh sách tại https://TEN-DU-AN.pages.dev/download.html

QUAN TRỌNG
- Không đặt mật khẩu admin trong file HTML/JavaScript.
- Không chia sẻ mật khẩu admin.
- Bản này dùng Cloudflare Pages Functions + D1 để mọi khách đều thấy các link bạn thêm.
- Nhạc nền trang chủ là giai điệu synth tạo bằng trình duyệt; cần bấm BẬT NHẠC.
- Ảnh hiện tại là ảnh mẫu từ Unsplash.
