import { makeCookie } from "./auth.js";
export async function onRequestPost({ request, env }) {
  if (!env.ADMIN_PASSWORD) return Response.json({error:"Chưa đặt ADMIN_PASSWORD trong Cloudflare."},{status:503});
  let body; try { body=await request.json(); } catch { return Response.json({error:"Dữ liệu không hợp lệ."},{status:400}); }
  if (typeof body.password !== "string" || body.password !== env.ADMIN_PASSWORD)
    return Response.json({error:"Mật khẩu không đúng."},{status:401});
  return new Response(JSON.stringify({ok:true}), {headers:{"Content-Type":"application/json","Set-Cookie":await makeCookie(env.ADMIN_PASSWORD)}});
}
