const COOKIE = "hs_admin";
const enc = new TextEncoder();
function toB64(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll("+","-").replaceAll("/","_").replaceAll("=",""); }
async function sign(value, secret) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), {name:"HMAC",hash:"SHA-256"}, false, ["sign"]);
  return toB64(await crypto.subtle.sign("HMAC", key, enc.encode(value)));
}
export async function makeCookie(secret) {
  const payload = String(Date.now() + 24*60*60*1000);
  const value = payload + "." + await sign(payload, secret);
  return `${COOKIE}=${value}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=86400`;
}
export async function isAdmin(request, secret) {
  if (!secret) return false;
  const raw = request.headers.get("Cookie") || "";
  const match = raw.split(";").map(x=>x.trim()).find(x=>x.startsWith(COOKIE+"="));
  if (!match) return false;
  const value = match.slice(COOKIE.length+1), parts = value.split(".");
  if (parts.length !== 2 || !/^\d+$/.test(parts[0]) || Number(parts[0]) < Date.now()) return false;
  return parts[1] === await sign(parts[0], secret);
}
export function clearCookie() { return `${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`; }
