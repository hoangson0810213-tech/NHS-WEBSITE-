import { isAdmin } from "./auth.js";
const json = (data,status=200)=>Response.json(data,{status});
function validUrl(value, optional=false) {
  if (optional && !value) return true;
  try { const u=new URL(value); return u.protocol==="https:" || u.protocol==="http:"; } catch { return false; }
}
export async function onRequest({ request, env }) {
  if (!await isAdmin(request, env.ADMIN_PASSWORD)) return json({error:"Bạn cần đăng nhập admin."},401);
  const method=request.method;
  if (method==="GET") {
    const {results}=await env.DB.prepare("SELECT id,name,category,description,url,image FROM downloads ORDER BY created_at DESC").all();
    return json(results);
  }
  if (method==="POST" || method==="PUT") {
    let b; try { b=await request.json(); } catch { return json({error:"Dữ liệu JSON không hợp lệ."},400); }
    const name=String(b.name||"").trim(), url=String(b.url||"").trim();
    const category=String(b.category||"DOWNLOAD").trim().slice(0,40);
    const description=String(b.description||"").trim().slice(0,240);
    const image=String(b.image||"").trim();
    if (!name || name.length>90 || !validUrl(url) || !validUrl(image,true)) return json({error:"Tên hoặc URL không hợp lệ. Link phải bắt đầu bằng http:// hoặc https://."},400);
    if (method==="POST") {
      const id=crypto.randomUUID();
      await env.DB.prepare("INSERT INTO downloads (id,name,category,description,url,image) VALUES (?,?,?,?,?,?)").bind(id,name,category,description,url,image).run();
      return json({ok:true,id},201);
    }
    const id=new URL(request.url).searchParams.get("id");
    if (!id) return json({error:"Thiếu ID mục cần sửa."},400);
    const result=await env.DB.prepare("UPDATE downloads SET name=?,category=?,description=?,url=?,image=? WHERE id=?").bind(name,category,description,url,image,id).run();
    return result.meta.changes ? json({ok:true}) : json({error:"Không tìm thấy mục."},404);
  }
  if (method==="DELETE") {
    const id=new URL(request.url).searchParams.get("id");
    if (!id) return json({error:"Thiếu ID mục cần xóa."},400);
    const result=await env.DB.prepare("DELETE FROM downloads WHERE id=?").bind(id).run();
    return result.meta.changes ? json({ok:true}) : json({error:"Không tìm thấy mục."},404);
  }
  return json({error:"Method không được hỗ trợ."},405);
}
