export async function onRequestGet({ env }) {
  try {
    const { results } = await env.DB.prepare(
      "SELECT id, name, category, description, url, image FROM downloads ORDER BY created_at DESC"
    ).all();
    return Response.json(results);
  } catch {
    return Response.json({ error: "Database chưa được cấu hình." }, { status: 503 });
  }
}
